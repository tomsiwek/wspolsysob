<?php
  include 'common/page.php';
  $page = new Page();
  $page->setPathToWebRoot('');
  $page->setPageTitle('SC14 BOF');
  $page->setNavIdentifier('events');
?>

<?php include 'common/header.html' ?>

<div class="breadcrumb"><a href="events.php">Events</a> - SC14 Birds-of-a-Feather</div>

<p> SC'14 New Orleans, LA, USA, Location and Time TBD</p>

<?php include 'common/footer.html' ?>
